# Collection Explorer  (CodePen API v2)

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/cwqbvlgk-the-styleful/pen/01a11a97-b156-725f-9d59-f45a1ba54fe0](https://codepen.io/editor/cwqbvlgk-the-styleful/pen/01a11a97-b156-725f-9d59-f45a1ba54fe0).

A Collection Explorer built with CodePen 2.0 and the REST API v2. Fetches and displays Pens through a PHP proxy, with pagination, sorting and raw JSON inspection. Includes configurable Collection ID and proxy URL for exploring your own Collections.